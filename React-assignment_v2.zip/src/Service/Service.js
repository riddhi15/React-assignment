import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './Service.css';
import View from './View';
import Modify from './Modify';
import $ from 'jquery';
class Service extends Component{
 
  jQuerycode = () => {
    const params = new URLSearchParams(window.location.search);
    const queryparameter = params.get("q");
     if(queryparameter == "view"){
      $("#view-data").show();
      $("#modify-data").hide();
      var newClass = window.location.href;
      newClass = newClass.substring(newClass.lastIndexOf('/')+1);
      $('body').addClass(newClass);
     }
     else if(queryparameter == "modify"){
      $("#view-data").hide();
      $("#modify-data").show();
      var newClass = window.location.href;
      newClass = newClass.substring(newClass.lastIndexOf('/')+1);
      $('body').addClass(newClass);
     }
  }
  componentDidMount(){
    this.jQuerycode()
  }
  render(){
    return (
      <div>
        <div id="view-data">
        <View />
        </div>
        <div id="modify-data">
        <Modify />
        </div>
        </div>
   );
     
  }

}
export default Service;


 