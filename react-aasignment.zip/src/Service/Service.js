import React, {Component} from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './Service.css';

class Service extends Component{
  constructor(){
    super();
    this.state = {
      data: [
        {id:1, firstName: 'firstNameTest1',  lastName:'lastNameTest1', type:'T'},
        {id:2, firstName: 'firstNameTest2',lastName:'lastNameTest2', type:'T'},
        {id:3, firstName: 'firstNameTest3', lastName:'lastNameTest3', type:'T'},
        {id:4, firstName: 'firstNameTest4',lastName:'lastNameTest4', type:'T'},
        {id:5, firstName: 'firstNameTest5',lastName:'lastNameTest5', type:'T'},
         
      ]
      // data :[{"id": "1", "firstName":"firstNameTest1", 
      //   "lastName":"lastNameTest1", "type":"T", "age":"20"}, {"id": "2", 
      //   "firstName":"firstNameTest2", "lastName":"lastNameTest2" , "type":"F", 
      //   "age":"25"} , {"id": "3", "firstName":"firstNameTest3", "lastName":"lastNameTest3"
      //   , "type":"F", "age":"30"} , {"id": "4", "firstName":"firstNameTest4", 
      //   "lastName":"lastNameTest4" , "type":"T", "age":"30"} , {"id": "5", 
      //   "firstName":"firstNameTest5", "lastName":"lastNameTest5" , "type":"T", 
      //   "age":"20"}]
    }
  }

  // shorter & readable 
  delete(item){
    const data = this.state.data.filter(i => i.id !== item.id)
    this.setState({data})
  }

 

  render(){
    const listItem = this.state.data.map((item)=>{
        return (
       
                     
                       <tr  key={item.id}>
                       <th scope="row">{item.id}</th>
                       <th scope="row">{item.firstName}</th>
                       <th scope="row">{item.lastName}</th>
                       <th scope="row">{item.type}</th>
                       <th scope="row"><button>Edit</button> <button onClick={this.delete.bind(this, item)} className="delete">Delete</button></th>
                     </tr>
                 
        )
    })
    return (
      <div className="main-wrapper">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
          <table class="table">
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Type</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
              {listItem}
              </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
    )
      
     
  }

}
export default Service;