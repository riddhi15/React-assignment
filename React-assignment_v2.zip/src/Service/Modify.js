import React, {Component, Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './Service.css';
import { Button,Modal} from 'react-bootstrap';  
class Modify extends Component{
  constructor(){
    super();
    this.state = {
      data: [
        {id:1, firstName: 'firstNameTest1',  lastName:'lastNameTest1', type:'T'},
        {id:2, firstName: 'firstNameTest2',lastName:'lastNameTest2', type:'T'},
        {id:3, firstName: 'firstNameTest3', lastName:'lastNameTest3', type:'T'},
        {id:4, firstName: 'firstNameTest4',lastName:'lastNameTest4', type:'T'},
        {id:5, firstName: 'firstNameTest5',lastName:'lastNameTest5', type:'T'},
         
      ],
      show:false,
      msg:""
    }
    // this.handleModal = this.handleModal.bind(this);
  }

  // shorter & readable 
  delete(item){
    const data = this.state.data.filter(i => i.id !== item.id)
    this.setState({data})
  }

  handleModal(message){  
    console.log(message)
    this.setState({show:!this.state.show,
      msg:this.state.message
    }) 
  
  }  

  render(){
    const listItem = this.state.data.map((item)=>{
        return (
                       <tr  key={item.id}>
                       <th scope="row">{item.id}</th>
                       <th scope="row">{item.firstName}</th>
                       <th scope="row">{item.lastName}</th>
                       <th scope="row">{item.type}</th>
                       <th scope="row"><button className='text-black-100 edit' onClick={()=>this.handleModal(item)}>Edit</button> <button onClick={this.delete.bind(this, item)} className="delete">Delete</button></th>
                     </tr>
                 
        )
    })
    
    return (
      <div className="main-wrapper">
      <div className="container">
        <div className="row">
          <div className="col-md-12">
          <table className="table">
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">First Name</th>
                  <th scope="col">Last Name</th>
                  <th scope="col">Type</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>
              <tbody>
              {listItem}
              </tbody>
              </table>
              
              </div>
              <div>  
            <Modal show={this.state.show} onHide={()=>this.handleModal()} >  
              <Modal.Header closeButton>Edit User</Modal.Header>
              <Modal.Body>  
                <form>
                <div className="form-group">
                  <label for="userID">ID</label>
                  <input type="text" className="form-control" id="userID" readOnly value="" />
                </div>
                <div className="form-group">
                  <label for="firstname">First Name</label>
                  <input type="text" className="form-control" id="firstname" value="" />
                </div>
                <div className="form-group">
                  <label for="lastname">Last Name</label>
                  <input type="text" className="form-control" id="lastname" value="" />
                </div>
                <div className="form-group">
                  <label for="type">Type</label>
                  <input type="text" className="form-control" id="type" value="" />
                </div>
                 
              </form>
              </Modal.Body>  
             
              <Modal.Footer>  
                <Button onClick={()=>this.handleModal()}>Close</Button>  
                <Button onClick={()=>this.handleModal()}>Save</Button>  
              </Modal.Footer>  
            </Modal>  
          </div>  
            </div>
          </div>
        </div>
    )
      
     
  }

}
export default Modify;