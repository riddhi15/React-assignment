import React, {Component} from 'react';
import HomeComponent from '../../HomeComponent/HomeComponent';
import Service from '../../Service/Service';
import View from '../../Service/View';
import Modify from '../../Service/Modify';
import PageNotFound from '../../PageNotFound/PageNotFound'; 
import {BrowserRouter as Router, Route, NavLink, Switch} from 'react-router-dom';
import './Nav.css';
import { Fragment } from 'react'
import { Menu, Transition } from '@headlessui/react'
import { ChevronDownIcon } from '@heroicons/react/solid'

function classNames(...classes) {
  return classes.filter(Boolean).join(' ')
}
class NavComponent extends Component{
  constructor(props) {
    super(props);
    this.state = {
      menu: false
    };
    this.toggleMenu = this.toggleMenu.bind(this);
  }
  toggleMenu(){
    this.setState({ menu: !this.state.menu })
  }

  render(){
    const show = (this.state.menu) ? "show" : "" ;
    return(
      <Router forceRefresh>
       
      <div className = "container">
        <div className = "row">
          <div className = "col-sm-12">
                 
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
  
          <button className="navbar-toggler" type="button"  onClick={ this.toggleMenu }>
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className={"collapse navbar-collapse " + show} id="navbarSupportedContent" >
            <ul className="navbar-nav mr-auto">
              <li className="nav-item active">
                <NavLink exact activeClassName = "active" className = "nav-link" to = "/">Home</NavLink>
              </li>
              
              <li className="nav-item dropdown">
              <Menu as="div" className="relative inline-block text-left">
      <div>
        <Menu.Button className="inline-flex justify-center w-full rounded-md   px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 focus:ring-indigo-500">
        Services
          <ChevronDownIcon className="-mr-1 ml-2 h-5 w-5" aria-hidden="true" />
        </Menu.Button>
      </div>

      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="origin-top-right absolute right-0 mt-2 w-56 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 focus:outline-none z-10">
          <div className="py-1">
            <Menu.Item>
              {({ active }) => (
              
                <NavLink activeClassName = "active" className = {classNames(
                  active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                  'block px-4 py-2 text-sm'
                )} to = "/Service?q=view">View</NavLink>
              )}
            </Menu.Item>
            <Menu.Item>
              {({ active }) => (
               <NavLink activeClassName = "active" className = {classNames(
                active ? 'bg-gray-100 text-gray-900' : 'text-gray-700',
                'block px-4 py-2 text-sm'
              )} to = "/Service?q=modify">Modify</NavLink>
              )}
            </Menu.Item>
         
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
            </li>
            </ul>
            
          </div>
        </nav>
            <Switch>
              <Route exact path = '/' component = {HomeComponent} />
              <Route path = '/Service' component = {Service} />
              <Route path = '/View' component = {View} />
              <Route path = '/Modify' component = {Modify} />
              <Route component = {PageNotFound} />
            </Switch>
          </div>
        </div>
      </div>
     
    </Router>
)

}
}
export default NavComponent ;